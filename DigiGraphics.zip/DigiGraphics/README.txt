Usage:
./DigiGraphics [/path/to/arm9.bin] [/dir/to/extracted/graphics/]

If you also want each graphic to be archived in a NARC, please use the following command:
./DigiGraphics [/path/to/arm9.bin] [/path/to/narctool.exe] [/dir/to/extracted/graphics/]


